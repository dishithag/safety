package summarizer

import (
	"encoding/json"
	"fmt"
	"io"
	"strings"
)

const maxAdminTerminology = 3

// NarrativeGuidance is the bounded, structured content returned by the LLM.
type NarrativeGuidance struct {
	Platforms []PlatformGuidance `json:"platforms"`
}

// PlatformGuidance contains technical guidance for one analyzed platform.
type PlatformGuidance struct {
	Name                string            `json:"name"`
	Findings            []ControlGuidance `json:"findings"`
	RemediationSequence []string          `json:"remediation_sequence"`
	SharedBlockers      []GuidanceBlocker `json:"shared_blockers"`
	FleetGuidance       string            `json:"fleet_guidance"`
}

// ControlGuidance provides technical guidance for one selected partial-compliance signal.
type ControlGuidance struct {
	Signal string `json:"signal"`
	TechnicalGuidance
}

// TechnicalGuidance captures the required and optional content for an actionable finding.
type TechnicalGuidance struct {
	WhyItMatters         string       `json:"why_it_matters"`
	SignalInterpretation string       `json:"signal_interpretation,omitempty"`
	RemediationSteps     []string     `json:"remediation_steps"`
	ChangeImpact         ChangeImpact `json:"change_impact"`
	VerificationSteps    []string     `json:"verification_steps"`
	AdminTerminology     []string     `json:"admin_terminology,omitempty"`
}

// ChangeImpact describes the estimated operational impact of making a change.
type ChangeImpact struct {
	Level     string `json:"level"`
	Rationale string `json:"rationale"`
}

// GuidanceBlocker maps a common implementation blocker to its response.
type GuidanceBlocker struct {
	Blocker  string `json:"blocker"`
	Response string `json:"response"`
}

// ParseNarrativeGuidance decodes and validates a model response against the prepared report facts.
func ParseNarrativeGuidance(raw string, analysis *ReportAnalysis) (*NarrativeGuidance, error) {
	if analysis == nil {
		return nil, fmt.Errorf("parse narrative guidance: analysis is nil")
	}

	response, err := unwrapJSONResponse(raw)
	if err != nil {
		return nil, fmt.Errorf("parse narrative guidance: %w", err)
	}

	decoder := json.NewDecoder(strings.NewReader(response))
	var guidance NarrativeGuidance
	if err := decoder.Decode(&guidance); err != nil {
		return nil, fmt.Errorf("parse narrative guidance JSON: %w", err)
	}
	if err := ensureJSONEOF(decoder); err != nil {
		return nil, fmt.Errorf("parse narrative guidance JSON: %w", err)
	}
	if err := validateNarrativeGuidance(&guidance, analysis); err != nil {
		return nil, fmt.Errorf("validate narrative guidance: %w", err)
	}
	return &guidance, nil
}

func unwrapJSONResponse(raw string) (string, error) {
	response := strings.TrimSpace(raw)
	if response == "" {
		return "", fmt.Errorf("response is empty")
	}
	if !strings.HasPrefix(response, "```") {
		return response, nil
	}

	lines := strings.Split(response, "\n")
	if len(lines) < 3 || strings.TrimSpace(lines[len(lines)-1]) != "```" {
		return "", fmt.Errorf("response contains an incomplete JSON code fence; model output may have been truncated")
	}
	openingFence := strings.TrimSpace(lines[0])
	language := strings.TrimSpace(strings.TrimPrefix(openingFence, "```"))
	if !strings.HasPrefix(openingFence, "```") || (language != "" && !strings.EqualFold(language, "json")) {
		return "", fmt.Errorf("response contains an unsupported JSON code fence %q", openingFence)
	}
	return strings.TrimSpace(strings.Join(lines[1:len(lines)-1], "\n")), nil
}

func ensureJSONEOF(decoder *json.Decoder) error {
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		if err == nil {
			return fmt.Errorf("response contains more than one JSON value")
		}
		return err
	}
	return nil
}

func validateNarrativeGuidance(guidance *NarrativeGuidance, analysis *ReportAnalysis) error {
	if len(guidance.Platforms) != len(analysis.Platforms) {
		return fmt.Errorf("platform count = %d, want %d", len(guidance.Platforms), len(analysis.Platforms))
	}

	for i := range analysis.Platforms {
		expected := &analysis.Platforms[i]
		actual := &guidance.Platforms[i]
		if actual.Name != expected.Name {
			return fmt.Errorf("platform %d name = %q, want %q", i, actual.Name, expected.Name)
		}
		if len(actual.Findings) != len(expected.PrioritySignals) {
			return fmt.Errorf("platform %q finding count = %d, want %d", expected.Name, len(actual.Findings), len(expected.PrioritySignals))
		}
		for findingIndex := range expected.PrioritySignals {
			finding := &actual.Findings[findingIndex]
			expectedSignal := expected.PrioritySignals[findingIndex].Signal
			if finding.Signal != expectedSignal {
				return fmt.Errorf("platform %q finding %d signal = %q, want %q", expected.Name, findingIndex, finding.Signal, expectedSignal)
			}
			if err := validateTechnicalGuidance(&finding.TechnicalGuidance); err != nil {
				return fmt.Errorf("platform %q signal %q: %w", expected.Name, finding.Signal, err)
			}
		}
		if err := validatePlatformImplementation(actual, expected); err != nil {
			return fmt.Errorf("platform %q implementation guidance: %w", expected.Name, err)
		}
	}

	return nil
}

func validatePlatformImplementation(guidance *PlatformGuidance, platform *PlatformAnalysis) error {
	hasFindings := len(platform.PrioritySignals) > 0
	if !hasFindings {
		if len(guidance.RemediationSequence) != 0 || len(guidance.SharedBlockers) != 0 || strings.TrimSpace(guidance.FleetGuidance) != "" {
			return fmt.Errorf("received implementation guidance for a platform without findings")
		}
		return nil
	}

	if len(guidance.RemediationSequence) < 2 || len(guidance.RemediationSequence) > 5 {
		return fmt.Errorf("remediation_sequence count = %d, want 2..5", len(guidance.RemediationSequence))
	}
	for i, step := range guidance.RemediationSequence {
		if strings.TrimSpace(step) == "" {
			return fmt.Errorf("remediation_sequence[%d] is empty", i)
		}
	}
	if len(guidance.SharedBlockers) > 3 {
		return fmt.Errorf("shared_blockers count = %d, maximum is 3", len(guidance.SharedBlockers))
	}
	for i, blocker := range guidance.SharedBlockers {
		if strings.TrimSpace(blocker.Blocker) == "" || strings.TrimSpace(blocker.Response) == "" {
			return fmt.Errorf("shared_blockers[%d] requires blocker and response", i)
		}
	}
	return nil
}

func validateTechnicalGuidance(guidance *TechnicalGuidance) error {
	required := []struct {
		name  string
		value string
	}{
		{"why_it_matters", guidance.WhyItMatters},
		{"change_impact.rationale", guidance.ChangeImpact.Rationale},
	}
	for _, field := range required {
		if strings.TrimSpace(field.value) == "" {
			return fmt.Errorf("%s is empty", field.name)
		}
	}

	level := strings.ToLower(strings.TrimSpace(guidance.ChangeImpact.Level))
	switch level {
	case "low":
		guidance.ChangeImpact.Level = "Low"
	case "moderate":
		guidance.ChangeImpact.Level = "Moderate"
	case "high":
		guidance.ChangeImpact.Level = "High"
	default:
		return fmt.Errorf("change_impact.level = %q, want Low, Moderate, or High", guidance.ChangeImpact.Level)
	}

	if len(guidance.RemediationSteps) < 2 || len(guidance.RemediationSteps) > 4 {
		return fmt.Errorf("remediation_steps count = %d, want 2..4", len(guidance.RemediationSteps))
	}
	for i, step := range guidance.RemediationSteps {
		if strings.TrimSpace(step) == "" {
			return fmt.Errorf("remediation_steps[%d] is empty", i)
		}
	}
	if len(guidance.VerificationSteps) == 0 || len(guidance.VerificationSteps) > 2 {
		return fmt.Errorf("verification_steps count = %d, want 1..2", len(guidance.VerificationSteps))
	}
	for i, step := range guidance.VerificationSteps {
		if strings.TrimSpace(step) == "" {
			return fmt.Errorf("verification_steps[%d] is empty", i)
		}
	}
	guidance.AdminTerminology = normalizeAdminTerminology(guidance.AdminTerminology)
	return nil
}

func normalizeAdminTerminology(values []string) []string {
	result := make([]string, 0, min(len(values), maxAdminTerminology))
	seen := make(map[string]struct{}, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		key := strings.ToLower(value)
		if _, duplicate := seen[key]; duplicate {
			continue
		}
		seen[key] = struct{}{}
		result = append(result, value)
		if len(result) == maxAdminTerminology {
			break
		}
	}
	return result
}
