package summarizer

import (
	"strings"
	"testing"
	"time"
)

func TestLoadConfigBatchDefaults(t *testing.T) {
	t.Setenv("SUMMARIZER_CONCURRENCY", "")
	t.Setenv("SUMMARIZER_GENERATION_TIMEOUT", "")
	t.Setenv("GENAI_HUB_MAX_OUTPUT_TOKENS", "")
	t.Setenv("GENAI_HUB_PLATFORMS_PER_REQUEST", "")

	cfg, err := LoadConfig("test-service")
	if err != nil {
		t.Fatalf("LoadConfig returned unexpected error: %v", err)
	}
	if got, want := cfg.Concurrency, 3; got != want {
		t.Fatalf("Concurrency = %d, want %d", got, want)
	}
	if got, want := cfg.GenerationTimeout, 15*time.Minute; got != want {
		t.Fatalf("GenerationTimeout = %s, want %s", got, want)
	}
	if got, want := cfg.GenAIHubMaxOutputTokens, int64(16384); got != want {
		t.Fatalf("GenAIHubMaxOutputTokens = %d, want %d", got, want)
	}
	if got, want := cfg.GenAIHubPlatformsPerRequest, 3; got != want {
		t.Fatalf("GenAIHubPlatformsPerRequest = %d, want %d", got, want)
	}
}

func TestLoadConfigBatchOverrides(t *testing.T) {
	t.Setenv("SUMMARIZER_CONCURRENCY", "7")
	t.Setenv("SUMMARIZER_GENERATION_TIMEOUT", "90s")
	t.Setenv("GENAI_HUB_MAX_OUTPUT_TOKENS", "12000")
	t.Setenv("GENAI_HUB_PLATFORMS_PER_REQUEST", "2")

	cfg, err := LoadConfig("test-service")
	if err != nil {
		t.Fatalf("LoadConfig returned unexpected error: %v", err)
	}
	if got, want := cfg.Concurrency, 7; got != want {
		t.Fatalf("Concurrency = %d, want %d", got, want)
	}
	if got, want := cfg.GenerationTimeout, 90*time.Second; got != want {
		t.Fatalf("GenerationTimeout = %s, want %s", got, want)
	}
	if got, want := cfg.GenAIHubMaxOutputTokens, int64(12000); got != want {
		t.Fatalf("GenAIHubMaxOutputTokens = %d, want %d", got, want)
	}
	if got, want := cfg.GenAIHubPlatformsPerRequest, 2; got != want {
		t.Fatalf("GenAIHubPlatformsPerRequest = %d, want %d", got, want)
	}
}

func TestLoadConfigRejectsInvalidBatchSettings(t *testing.T) {
	tests := []struct {
		name  string
		key   string
		value string
	}{
		{name: "non-numeric concurrency", key: "SUMMARIZER_CONCURRENCY", value: "many"},
		{name: "zero concurrency", key: "SUMMARIZER_CONCURRENCY", value: "0"},
		{name: "invalid timeout", key: "SUMMARIZER_GENERATION_TIMEOUT", value: "later"},
		{name: "zero timeout", key: "SUMMARIZER_GENERATION_TIMEOUT", value: "0s"},
		{name: "non-numeric max output tokens", key: "GENAI_HUB_MAX_OUTPUT_TOKENS", value: "many"},
		{name: "zero max output tokens", key: "GENAI_HUB_MAX_OUTPUT_TOKENS", value: "0"},
		{name: "non-numeric platforms per request", key: "GENAI_HUB_PLATFORMS_PER_REQUEST", value: "many"},
		{name: "zero platforms per request", key: "GENAI_HUB_PLATFORMS_PER_REQUEST", value: "0"},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Setenv("SUMMARIZER_CONCURRENCY", "")
			t.Setenv("SUMMARIZER_GENERATION_TIMEOUT", "")
			t.Setenv("GENAI_HUB_MAX_OUTPUT_TOKENS", "")
			t.Setenv("GENAI_HUB_PLATFORMS_PER_REQUEST", "")
			t.Setenv(test.key, test.value)

			_, err := LoadConfig("test-service")
			if err == nil {
				t.Fatal("LoadConfig returned nil error")
			}
			if !strings.Contains(err.Error(), test.key) {
				t.Fatalf("error = %q, want it to mention %s", err, test.key)
			}
		})
	}
}
