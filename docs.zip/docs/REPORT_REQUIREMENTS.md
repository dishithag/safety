# Analyst Report Requirements

This document captures the stakeholder target used to design and review the
prompt, deterministic analysis, and Markdown renderer.

## Audience and purpose

The primary reader is a security analyst responsible for improving a
customer's Zero Trust Assessment posture. The report should help that analyst
understand what matters, why it matters, how to remediate it, what disruption
the change may cause, and how to verify success.

This is not an executive report. A shorter executive summary would require a
separate prompt and presentation.

## Selection rules

- Analyze every platform independently.
- Show every zero-compliance signal. A reported zero means no compliant
  coverage was observed; it does not by itself prove the control is absent or
  disabled.
- Follow each zero-compliance table with the same deterministic list of common
  diagnostic possibilities. Do not ask the model to group, define, or prescribe
  remediation for zero-compliance controls.
- Select the three lowest non-zero, partially compliant signal values per
  platform and preserve equal values at the selection boundary.
- Do not recommend unnecessary fleet-wide remediation when signals are fully or
  almost fully compliant.
- Preserve signal IDs alongside readable control names so analysts can map the
  narrative back to source data.

The report explains the selected findings without exposing internal selection
phrasing such as "cutoff ties."

## Expected structure

```markdown
# Zero Trust Assessment Report

**CID:** `{cid}`
**Reported devices:** **{count}**

## High-Level Overview

Score scale and concise definitions for each reported score. Do not restate
obvious numeric comparisons as observations.

---

## 1. {Platform}

Platform scores and a positive observation or coverage note.

### Zero-Compliance Gaps

Summary table containing every zero-compliance control, followed by common
reasons to investigate and a reminder that they are not confirmed causes.

---

### Lowest-Coverage Improvement Opportunities

Coverage-based summary table followed by technical guidance for each selected
control. This section does not claim to be a security-severity ranking.

### Recommended Remediation Sequence (when applicable)

Ordered implementation steps only when multiple findings have a genuine shared
prerequisite, dependency, or required rollout order. Omit this section for
independent findings rather than repeating their remediation steps.

---

## Recommended Next Steps

Short, deterministic actions derived from the report facts.
```

Sections that have no applicable data are omitted or replaced by a concise
positive/data-availability note.

## Guidance required for each selected non-zero finding

- A concise plain-English explanation combining the control's purpose and
  potential security impact.
- A conservative signal interpretation only when the reported state can be
  explained without claiming undocumented CrowdStrike evaluation behavior.
- Useful administrator terminology, limited to nonduplicate names an analyst
  may encounter.
- Platform-specific remediation steps in implementation order.
- Estimated change impact with a factual rationale that includes material
  prerequisites, compatibility, reboot, downtime, or rollback concerns.
- Concrete verification steps or commands.

Shared blockers, dependency ordering, and fleet rollout guidance should be
presented once per platform only when supported by relationships between
multiple findings. Do not manufacture platform-level guidance merely because
several findings were selected.

Zero-compliance sections are deterministic. They do not contain model-generated
definitions, terminology, remediation, implementation-impact ratings, or verification
steps because an aggregate zero does not establish the underlying cause.

## Quality constraints

- Ground scores, platform names, signal IDs, selected controls, and device
  counts in the source report.
- Do not invent scoring formulas, severity bands, customer environment details,
  or guarantees that remediation will increase a score by a specific amount.
- Keep paragraphs short and prefer tables and lists where they improve scanning.
- Give positive observations when supported instead of making every report
  uniformly negative.
- Treat implementation-impact labels as estimates and explain their basis.
- Keep report structure stable across CIDs while allowing technical guidance to
  vary by platform and control.

## Implementation responsibility

Go owns source parsing, score availability, finding selection, validation,
ordering, and final Markdown formatting. Claude returns grounded technical
guidance for the supplied findings. Multi-platform reports may use multiple
bounded Claude requests, but Go combines them into one report in source platform
order. Harmless response deviations are normalized, invalid structure receives
one repair attempt, and factual mismatches remain strict. If guidance still
cannot be validated, Go writes a clearly marked deterministic fallback with
current source facts and metadata that causes a future GenAI run to retry. A
separate `zta_definitions.json` input was explicitly de-scoped for the current
implementation.
