# Remaining Work and Recorded Decisions

Current implementation status and follow-up work for the zerotrust-analytics
pipeline.

**Goal:** Read per-CID ZTA audit reports from S3, generate analyst-focused
Markdown narratives, write them back to S3, and serve them through the
analytics API.

## Current state

| Component | State |
| --- | --- |
| Report model and parsing | Implemented, including nullable score presence and fixture coverage. |
| Object-store input | Discovers and loads `reports/cids/{cid}.json` from S3/minio. |
| Narrative generation | Supports deterministic placeholder/fallback output, one structured-response repair attempt, and chunked GenAI Hub/Claude guidance for large multi-platform reports. |
| Markdown format | Go selects facts and controls and renders a stable analyst-focused structure. |
| Batch execution | Bounded concurrency, per-CID failure isolation, timeouts, progress, and final tallies. |
| Freshness | Skips only when the report SHA-256 and generation profile still match. |
| Object-store output | Writes one `summary/cids/{cid}.md` object with freshness metadata. |
| Analytics API | Returns stored Markdown by CID and maps missing narratives to `404`. |
| Tests | Unit/fake coverage plus an opt-in end-to-end test against local minio. |
| Local demo | Tilt deploys and connects minio, the summarizer Job, and analyticsapi. |
| Demo UI | Implemented as an isolated React/Vite application with MinIO-backed report discovery and Markdown rendering. |
| Analytics preview | Implemented with clearly labelled seven-day synthetic history for eight CIDs. |

The complete local data path is implemented:

```text
reports/cids/{cid}.json
        -> summarizer
        -> GenAI Hub/Claude or placeholder provider
        -> summary/cids/{cid}.md
        -> GET /zero-trust-analytics/narratives/{cid}
```

## Decisions

- **Audience:** A security analyst responsible for understanding and improving
  the organization's ZTA posture. Executive reporting would use a separate
  prompt and report format.
- **Report content:** High-level score context, per-platform findings,
  deterministic zero-compliance diagnostics, lowest-coverage
  partial-compliance opportunities, technical remediation, estimated
  implementation impact, verification, optional dependency-based remediation sequencing, and
  deterministic report-wide next steps.
- **Responsibility split:** Go owns report parsing, fact selection, control
  selection, zero-compliance tables and diagnostic possibilities, validation,
  ordering, and Markdown structure. Claude supplies grounded explanations and
  platform-specific technical guidance only for selected non-zero findings.
  Large reports are sent in bounded platform groups and combined only after
  every response is validated. Harmless deviations are normalized, invalid
  structure receives one repair attempt, and a deterministic fallback keeps
  current report facts available when generated guidance still fails.
- **Signal grounding:** A separate `zta_definitions.json` dependency was
  explicitly de-scoped. The report's platform and signal data is the grounding
  source for the current implementation.
- **Summary storage:** One Markdown object per CID at
  `summary/cids/{cid}.md`. Freshness data is S3 object metadata, not a sidecar
  JSON object.
- **Rerun behavior:** A summary is current only when its source SHA-256, summary
  version, narrative provider, and model match. Changed reports or generation
  profiles are regenerated. Fallback summaries use a distinct provider so a
  later GenAI run retries them.
- **Offline mode:** `NARRATIVE_PROVIDER=placeholder` exercises parsing,
  analysis, batching, storage, and serving without an LLM call.
- **Local authentication:** None for the demo. Production authentication and
  managed secrets are outside the MVP.

## Demo acceptance checks

Before the final share-out:

1. Start from a clean local namespace and run `tilt up`.
2. Confirm `minio-setup` completes before the summarizer starts.
3. Confirm the summarizer reports the expected processed, fallback, skipped, and
   failed counts.
4. Fetch at least two generated CID narratives through analyticsapi.
5. Confirm an unknown CID returns `404`.
6. Run the normal unit suite.
7. Run `TestMinIOPipelineEndToEnd` against local minio.
8. Capture the exact commands and representative output for the final
   share-out.

The root `README.md` contains the commands for these checks.

## Completed demo work

- Built the isolated demo UI for CID lookup and readable Markdown rendering.
- Added clearly labelled synthetic trend fixtures for the future-scope preview.
- Documented the approach, current behavior, limitations, and recommended next
  steps in [`PROJECT_HANDOFF.md`](PROJECT_HANDOFF.md).

## Remaining handoff checks

- Run the clean-namespace Tilt acceptance flow on the destination work laptop.
- Capture representative batch, API, fallback, and UI output for the final
  internal handoff.
- Confirm the approved GenAI Hub model and credential-delivery process before a
  live-provider demonstration.

Synthetic trend fixtures are presentation data only. They must not be described
as production history or written into the normal report and summary prefixes.

## Production follow-up

These items are intentionally outside the local MVP:

- Confirm expected CID volume, GenAI Hub rate limits, cost, and batch-duration
  targets before selecting production concurrency.
- Classify transient and permanent GenAI errors; add bounded retry/backoff with
  jitter and rate-limit handling for transient failures.
- Add durable per-CID run state, targeted reprocessing, circuit breaking,
  metrics, alerting, and a production runbook.
- Convert the one-shot Job to a scheduled workload with overlap controls.
- Store credentials in the approved managed-secret system and add API
  authentication and authorization.
- Validate against real S3 and define resource requests, limits, and deployment
  availability requirements.
- Decide whether production retains dated report snapshots. If it does, define
  bounded retention and S3 lifecycle rules. Real trend analysis requires
  explicit historical data rather than only the latest per-CID object.
