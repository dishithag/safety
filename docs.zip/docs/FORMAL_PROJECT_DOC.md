# Intern Project: ZTA LLM Summaries

> **Document status:** Original project charter and scope. For the implemented
> MVP, current decisions, and explicitly de-scoped items, see
> [`PROJECT_HANDOFF.md`](PROJECT_HANDOFF.md) and
> [`REMAINING_WORK.md`](REMAINING_WORK.md).

| Manager | [Paul Ott](mailto:paul.ott@crowdstrike.com) |
| :---- | :---- |
| Intern | Dishitha Gurram |
| Department | Engineering & Product |
| E-Staff Leader | Karan Gupta |
| Department Lead | Deepak Ramakumar |
| Project Title | Zero Trust Assessment LLM Summaries |
| Mentor | [Jaxson Hawkins](mailto:jaxson.hawkins@crowdstrike.com) |
| Alternate Manager |  |

## Project/Work Priorities Summary

The Zero Trust Assessment (ZTA) service is a high-throughput, event-driven pipeline that computes security risk scores for endpoints across the CrowdStrike platform. It ingests millions of device events daily from Kafka, runs an 8-stage evaluation pipeline against \~50+ security signals per platform (OS settings, prevention policies, RTR, device detail, system tags), and stores per-device assessments in OpenSearch. Customers consume this data through ztaapi to understand their fleet's Zero Trust posture.

ZTA already operates a weekly cron job (csztareporter-cronjob) that aggregates assessment data per Customer ID (CID) and writes structured JSON reports to S3 (reports/cids/{cid}.json). These reports contain:

- Total devices assessed (NumAIDs)  
- Average overall, OS, and sensor scores (0–100)  
- Per-platform breakdowns across Windows Server (2016/2019/2022/2025), Windows 10/11, macOS, Linux, iOS, and Android  
- Per-signal compliance percentages for \~50+ signals per platform

Customers currently access this data via the GET /entities/audit/v1 endpoint, which returns raw structured JSON only — no narrative, no prioritization, no remediation guidance, no trend analysis, no notifications.

These are the following business metrics that are tracked today.

- Volume: Millions of device events per day; assessments computed across thousands of CIDs  
- Coverage: Number of CIDs actively consuming the audit endpoint  
- Posture metrics: Average overall score per CID, per-signal compliance %, failing-assessment counts  
- Operational SLOs: Reporter cron success rate, OpenSearch query latency, Kafka consumer lag  
- Engagement (gap today): There is no metric for whether customers actually act on audit data — no open-rate, no remediation-completion tracking. Establishing baseline engagement would itself be a project outcome.

The audit JSON contains rich, actionable detail, but consuming it requires humans to interpret raw signal percentages against ZTA's signal taxonomy. There is no human-readable report, no recommendation, no week-over-week diff, and no per-CID customization. Customers without dedicated security engineering resources can struggle to translate the data into action.

## Business Context and Impact

### Customer Value

- Lowers the bar for smaller customers to operationalize Zero Trust posture data  
- Increases the value of an existing data asset that customers already have access to but may not be using effectively  
- Differentiates the ZTA product by moving from "raw data export" to "analyst-grade insights"

### Strategic Alignment

- AI-native platform: Embedding LLM-driven insights into customer-facing surfaces aligns with CrowdStrike's broader push to ship AI-powered features  
- Higher-quality ZTA reporting strengthens the case for ZTA as a core posture-management capability inside the Falcon platform.  
- Customer outcomes / time-to-value: A guided narrative report shortens the path from "data delivered" to "risk reduced," which is a recurring theme in customer success and renewals.  
- Defensive AI use case: A bounded, batch, high-trust LLM application — a strong example of responsible internal AI adoption.

Engineering Value

- Demonstrates a pattern (structured-data → LLM → narrative) that other CrowdStrike services with similar reporting needs can reuse.  
- Opens the door (as a stretch) to a reusable evaluation harness for LLM output quality that could extend beyond ZTA.

---

## Project Goals & Deliverables

### Primary Goal

Build a system that consumes the existing nightly/weekly ZTA audit JSON for a CID and produces a customized, human-readable security posture report that prioritizes findings, provides remediation guidance, and is delivered locally for a stakeholder demo. Productionizing the system — deploying it into Raven, sourcing config via Raven Params, adding CSAM auth, and wiring delivery into the real ztaapi surface — is a stretch goal, not part of the core deliverable.

Required Deliverables (MVP — Must-Have for Success)

1. Narrative report generator \- Reads reports/cids/{cid}.json from S3 plus scripts/zta\_definitions.json for signal grounding \- Calls an approved LLM (GenAI Hub → Bedrock/Claude) to produce a structured Markdown report containing: executive summary, top findings, per-platform highlights, prioritized recommendations \- Writes output to S3/minio (default summary/cids/{cid}.md — open to a better layout if the intern proposes one)  
2. Local API delivery \- The analyticsapi service serves the generated narrative from S3/minio over its existing route (GET /zero-trust-analytics/narratives/{id}), runnable locally via Tilt \- No production authentication required for the demo  
3. Tests \- Unit and integration tests following the existing pattern  
4. Final share-out \- Demo of generated reports for sample CIDs \- Brief written summary of approach, results, and recommended next steps for the team

Stretch Deliverables (Nice-to-Have)

These also serve as the project's schedule buffer: if the MVP runs long, stretch work is what gives, and the intern picks from these as time and interest allow.

5. Productionization \- Deploy the service into Raven; source secrets/config via Raven Params; add CSAM authentication; wire delivery into the real ztaapi surface (e.g., GET /entities/audit-narrative/v1?cid=...)  
6. LLM verification / quality harness \- An automated check that each narrative is faithful to its source JSON. Deliberately open-ended: one approach is a second "judge" LLM that reviews each narrative against the input data for correctness; another is a deterministic check that every numeric claim traces back to a source value. A good place for the intern to explore.  
7. Week-over-week trend analysis (include multi-week context in the report)  
8. Benchmarking context using the existing reports/cloud\_audit.json rollup (“you’re in the bottom quartile of companies of a similar size”).

Project Timeline

| Weeks | Phase | Outcomes |
| :---- | :---- | :---- |
| 1–2 | Onboarding & setup | Local dev env, read ZTA codebase, ramp on Go |
| 3 | Discovery & design | Read existing reporter and audit handler; draft design doc; confirm LLM provider/security constraints with team |
| 4–5 | MVP narrative generator | First end-to-end pipeline producing Markdown for one CID, written to S3/minio |
| 6 | Local API delivery | analyticsapi serves the generated narrative from S3/minio; expand beyond a single CID |
| 7 | Prompt iteration + tests | Improve summary quality; unit + integration tests following the existing pattern |
| 8 | MVP demo-ready | Full local loop working under `tilt up`; README run instructions. (Buffer: absorbs any earlier slippage before stretch work begins.) |
| 9–11 | Stretch goals (as time allows) | Pick from: productionization (Raven, Raven Params, CSAM, real ztaapi), LLM verification harness, week-over-week trends, cloud-rollup benchmarking |
| 12 | Share-out | Demo, written summary, handoff |

---

## Scope Reduction Plan

If the scope must be cut to keep the project on track, the following can be removed without undermining MVP success:

First to cut (stretch goals — these are the buffer):

- Productionization (Raven, Raven Params, CSAM)  
- LLM verification / quality harness  
- Week-over-week trend analysis  
- Benchmarking against cloud-wide rollup

Can be cut within the MVP if needed:

- Local API delivery can be deferred in favor of S3-only delivery (show the generated Markdown directly in minio; the team can wire up serving later)  
- Multi-CID validation can be reduced to a smaller curated sample  
- Remediation recommendation depth can start with signal-level guidance only (no platform-specific how-to)

## Tools and Resources

### General

- Go — primary language of the ZTA codebase  
- OpenSearch / Elasticsearch — assessment storage and aggregation queries  
- AWS S3 / minio — report storage and configuration  
- Kubernetes / Raven — deployment platform  
- Kafka  — distributes events to and across ZTA  
- Tilt w/ colima k8s  — local environment bootstrapping  
- Grafana / Graphite — operational metrics and dashboards  
- LogScale / Splunk — structured log aggregation

### CrowdStrike-Specific

- CSAM — authentication and macaroon-token authorization  
- GenAI Hub — proxy for Bedrock / LLM calls such as Claude

### Process & Collaboration

- Git / Bitbucket — code review, PR workflow  
- Jira — ticket tracking
