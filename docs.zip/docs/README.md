# Documentation Index

## Start here

- Repository [`README.md`](../README.md): setup, Tilt workflow, storage layout,
  endpoints, and end-to-end verification.
- [`PROJECT_HANDOFF.md`](PROJECT_HANDOFF.md): implemented system, key behavior,
  verification checklist, limitations, and production follow-up.

## Product and design

- [`FORMAL_PROJECT_DOC.md`](FORMAL_PROJECT_DOC.md): original project charter,
  business context, goals, and timeline.
- [`REPORT_REQUIREMENTS.md`](REPORT_REQUIREMENTS.md): current analyst audience,
  selection rules, report structure, and quality constraints.
- [`REMAINING_WORK.md`](REMAINING_WORK.md): recorded implementation decisions,
  demo status, and production follow-up.
- [`DESIGN_DOC_TEMPLATE.md`](DESIGN_DOC_TEMPLATE.md): historical planning
  template. It is not the current implementation specification.

## Component documentation

- [`cmd/summarizer/README.md`](../cmd/summarizer/README.md): batch executable and
  result semantics.
- [`internal/summarizer/README.md`](../internal/summarizer/README.md): core
  analysis, GenAI, validation, fallback, freshness, configuration, and tests.
- [`cmd/analyticsapi/README.md`](../cmd/analyticsapi/README.md): REST API runtime,
  configuration, and endpoints.
- [`internal/analyticsapi/README.md`](../internal/analyticsapi/README.md): API
  layering and implementation details.
- [`demo-ui/README.md`](../demo-ui/README.md): UI setup, report catalog, and
  synthetic analytics scope.
- [`demo-ui/src/demo-data/trends/README.md`](../demo-ui/src/demo-data/trends/README.md):
  synthetic trend-fixture provenance and regeneration.
- [`demo-ui/src/demo-data/trends/WEEKLY_ANALYST_PROMPT.md`](../demo-ui/src/demo-data/trends/WEEKLY_ANALYST_PROMPT.md):
  future weekly-analyst prompt contract.

The root CID-named Markdown file is a generated narrative example, not project
documentation.
