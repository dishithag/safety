<!--
  Design-doc TEMPLATE for the ZTA LLM Summaries project (Jira: ZTALLM-5 / RISK-7261).

  HOW TO USE:
  1. Copy the rendered content of this template into a new Google Doc using
     Edit → Paste → "Paste from Markdown" (or right-click → Paste from markdown).
     That preserves the headings, tables, and code blocks as native Google Docs
     formatting.
  2. Fill it in there. Review, comments, and sharing happen in Google Docs for
     better collaboration and viewing — not in this repo.
  3. Delete the italic guidance prompts as you replace them with real content.
  Keep it concise — aim for something a reviewer can read in ~10 minutes.
-->

> **Document status:** Historical planning template. It contains prompts and
> early assumptions, not the final implementation contract. See
> [`PROJECT_HANDOFF.md`](PROJECT_HANDOFF.md),
> [`REPORT_REQUIREMENTS.md`](REPORT_REQUIREMENTS.md), and
> [`REMAINING_WORK.md`](REMAINING_WORK.md) for the implemented design.

# Design: ZTA LLM Summaries

| | |
| --- | --- |
| **Author** | Dishitha Gurram |
| **Reviewer(s)** | Jaxson Hawkins (mentor) |
| **Status** | Draft · In Review · Approved |
| **Last updated** | YYYY-MM-DD |
| **Related** | [FORMAL_PROJECT_DOC.md](FORMAL_PROJECT_DOC.md) · [REMAINING_WORK.md](REMAINING_WORK.md) · Jira epics RISK-7249…7256 |

## 1. Summary (TL;DR)
*Two or three sentences: what you're building and the shape of the solution. A
reader should understand the whole thing from this paragraph alone.*

## 2. Background & context
*What problem does this solve? What is a ZTA audit report, who consumes the
summaries, and why is raw JSON not enough today? Link to the report schema notes
from ZTALLM-3.*

## 3. Goals / Non-goals
**Goals**
- *e.g. produce a readable per-CID Markdown narrative from an audit report*
- *serve it locally via analyticsapi for a stakeholder demo*

**Non-goals** *(things explicitly out of scope — protects you from scope creep)*
- *Production deploy / Raven / CSAM (stretch only)*
- *Processing the full 100k report set at scale*

## 4. Design overview
*The big picture in one diagram + a paragraph. Show the data flow end to end:*

```
S3/minio (reports/cids/{cid}.json)
      │  read
      ▼
  summarizer ──► GenAI Hub (LLM) ──► Markdown narrative
      │  write
      ▼
S3/minio (summary/cids/{cid}.md)
      │  read
      ▼
  analyticsapi  ──►  GET /zero-trust-analytics/narratives/{cid}
```

*Walk through the flow in prose and name the components you'll add and which
layer (domain / usecase / gateway) each lives in.*

## 5. Detailed design
*One subsection per component. Describe behavior and interfaces, not line-by-line
code. Call out anything non-obvious.*

### 5.1 Data model
*The Go types for the report (cloud rollup + per-CID + compliance map). What you
parse, what you ignore.*

### 5.2 Object store layout
*Report keys (input) and the summary key scheme (output, default
`summary/cids/{cid}.md`). If you're proposing a different layout than the
default, justify it here.*

### 5.3 Summarizer (batch job)
*Read → summarize → write. How you handle: concurrency, skip-already-summarized,
per-report failure, and progress/observability. What "one run" does.*

### 5.4 LLM integration
*GenAI Hub model, prompt strategy, required response contract, grounding, and
how to test without calling a real LLM. The original proposal referenced
`zta_definitions.json`; the implemented MVP explicitly de-scoped that input and
uses the prepared report facts as its grounding source.*

### 5.5 API delivery
*The route, that `{id}` is the CID, the response format, and behavior when a
narrative is missing (404).*

## 6. Key decisions & alternatives considered
*The most valuable section. For each meaningful decision: what you chose, the
alternatives, and why. This is the artifact future-you / the team will reread.*

| Decision | Chosen approach | Alternatives considered | Why |
| --- | --- | --- | --- |
| Summary storage format | Markdown at `summary/cids/{cid}.md` | JSON-wrapped, single combined file | *…* |
| LLM provider | GenAI Hub (Bedrock/Claude) | *…* | approved path |
| *…* | | | |

## 7. Resolved open questions
*Walk through the open questions in [REMAINING_WORK.md](REMAINING_WORK.md) and
record the answer for each (the AC for this task requires all of them resolved).*

- **What does a "good" report look like?** *answer + link to the stakeholder example*
- **Dataset size & scale estimate** *answer*

## 8. Testing strategy
*Unit (fakes for S3 + LLM), fixture-based parsing tests, and the integration test
against local minio. What "tested" means for the MVP.*

## 9. Demo & rollout plan
*How the demo runs (`tilt up`), the curated demo dataset, and what you'll show
stakeholders.*

## 10. Risks & future work
*What could go wrong (LLM quality, cost, time), and what you're deliberately
leaving for later (the productionization stretch: Raven, Raven Params, CSAM,
real ztaapi).*

## Appendix
*Links, references, raw notes, the signal-grounding summary from ZTALLM-3, etc.*
