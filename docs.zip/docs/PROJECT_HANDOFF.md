# ZTA LLM Summaries: Project Handoff

This is the concise handoff guide for the implemented local MVP. It describes
what exists today, how the pieces connect, how to verify them, and which items
remain production follow-up.

## Project outcome

The project converts per-CID Zero Trust Assessment (ZTA) JSON reports into
analyst-focused Markdown narratives. Go owns the source facts, finding
selection, validation, ordering, and report layout. When enabled, Claude through
GenAI Hub supplies bounded technical guidance for selected non-zero findings.

```text
reports/cids/{cid}.json
        -> Go summarizer batch
        -> placeholder or GenAI Hub/Claude guidance
        -> Go validation and Markdown rendering
        -> summary/cids/{cid}.md
        -> analyticsapi REST endpoint
        -> demo UI
```

## Implemented components

| Component | Responsibility |
| --- | --- |
| `cmd/summarizer` | Discovers CID reports, processes them concurrently, records progress, and isolates per-CID failures. |
| `internal/summarizer` | Parses and analyzes reports, calls Claude when configured, validates guidance, renders Markdown, and reads/writes MinIO/S3 objects. |
| `cmd/analyticsapi` | Wires and starts the narrative REST API. |
| `internal/analyticsapi` | Reads stored Markdown and serves it by CID. |
| `demo-ui` | Lists stored narratives, renders Markdown, and demonstrates clearly labelled synthetic trend analytics. |
| `deploy` and `Tiltfile` | Run MinIO, seed reports, execute the summarizer Job, and expose analyticsapi locally. |

## Main technology stack

- Go backend summarizer and REST API
- Anthropic Go SDK connecting to Claude through CrowdStrike GenAI Hub
- React, TypeScript, and Vite demo UI
- MinIO locally and an S3-compatible production storage contract
- Docker containers and Kubernetes manifests
- Tilt and Colima/k3s for the local cloud-native environment
- JSON source reports and Markdown narrative output

## Key behavior

### Deterministic analysis

- Every platform is analyzed independently.
- All zero-compliance controls are displayed with deterministic diagnostic
  possibilities; zero values are not sent to Claude for remediation guidance.
- Go selects the lowest non-zero partial-compliance opportunities while
  preserving ties at the selection boundary.
- Go renders scores, control tables, implementation-impact labels, verification
  sections, and final Markdown structure.

### GenAI behavior

- `NARRATIVE_PROVIDER=placeholder` produces an offline deterministic report and
  makes no Claude request.
- `NARRATIVE_PROVIDER=genaihub` uses the Anthropic Go SDK against the configured
  GenAI Hub endpoint and model.
- Large reports are divided into bounded platform groups.
- A structurally invalid Claude response receives one repair request.
- A network error, timeout, refusal, truncation, failed repair, or second invalid
  response returns control to the batch, which attempts a deterministic fallback.

### Fallback behavior

The fallback contains current source scores, selected controls, zero-compliance
diagnostics, and deterministic next steps. It omits generated technical
remediation and displays a guidance-status notice in the Markdown.

Fallback objects are stored with the narrative provider
`deterministic-fallback`. That metadata does not match a requested `genaihub`
profile, so a later GenAI run attempts the CID again. Any fallback or failed CID
also makes the batch exit unsuccessfully after the final tally, while other CIDs
continue processing.

Fallback is only for generation failures when deterministic analysis is still
possible. Invalid source JSON, object-store read/write failures, and parent batch
cancellation remain failures.

### Freshness

A stored summary is skipped only when all of these still match:

- Source-report SHA-256
- Summary format version
- Narrative provider
- Model

Change `SummaryVersion` in `internal/summarizer/summary.go` whenever a renderer
or report-contract change must regenerate existing stored Markdown.

## Storage and API contract

| Artifact | Object key |
| --- | --- |
| CID source report | `reports/cids/{cid}.json` |
| Cloud rollup | `reports/cloud_audit.json` |
| Generated narrative | `summary/cids/{cid}.md` |

The local API exposes:

- `GET /healthz`
- `GET /zero-trust-analytics/narratives/{cid}`

Missing narratives return `404`. Other storage errors return `500`.

## Run and verify

Regular checks require no external service:

```shell
make build
make test
make vet

cd demo-ui
npm ci
npm run check:catalog
npm run check:trends
npm run build
```

Run the complete local infrastructure from the repository root:

```shell
colima start --kubernetes --runtime docker
tilt up
```

Tilt exposes analyticsapi on `localhost:8080`, MinIO on ports `9000` and
`9001`, and its own dashboard on port `10350`. The demo UI is intentionally
separate and is started from `demo-ui` with `npm run dev` on port `5173`.

With MinIO running, execute the opt-in end-to-end test:

```shell
RUN_MINIO_INTEGRATION=1 \
S3_ENDPOINT=http://localhost:9000 \
go test ./cmd/summarizer -run '^TestMinIOPipelineEndToEnd$' -v
```

## Demo data and analytics

The report fixtures under `testdata/sample_audit_reports` are synthetic. The
Analytics tab uses a separate seven-day, eight-CID synthetic history under
`demo-ui/src/demo-data/trends`. Historical analytics are presentation-only:
they are not production history, are not written to MinIO, and are not consumed
by the Go services.

## Production follow-up

The local MVP intentionally does not include:

- Raven deployment, Raven Params, or CSAM authorization
- Production credential management
- Scheduled execution and overlap controls
- Error-aware retries with exponential backoff and jitter
- Durable per-CID retry state or a reprocessing queue
- Rate-limit, token, latency, cost, repair, and fallback metrics
- Circuit breaking for a broader GenAI Hub outage
- Real historical report retention and trend generation
- A defined version-retention and S3 lifecycle policy
- Production S3 scale, resource, and availability validation

## Documentation map

Start with the repository [`README.md`](../README.md), then use:

- [`internal/summarizer/README.md`](../internal/summarizer/README.md) for the
  summarizer implementation and configuration.
- [`cmd/analyticsapi/README.md`](../cmd/analyticsapi/README.md) for the REST API.
- [`demo-ui/README.md`](../demo-ui/README.md) for the UI and synthetic analytics.
- [`REPORT_REQUIREMENTS.md`](REPORT_REQUIREMENTS.md) for the report contract.
- [`REMAINING_WORK.md`](REMAINING_WORK.md) for recorded decisions and future work.
- [`FORMAL_PROJECT_DOC.md`](FORMAL_PROJECT_DOC.md) for the original project charter.
