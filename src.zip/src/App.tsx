import { useDeferredValue, useEffect, useState } from "react";
import { ReportMarkdown, reportTableOfContents } from "./components/ReportMarkdown";
import { compactCID, demoReports, type DemoReport } from "./data/reports";

type NarrativeState =
  | { status: "loading"; markdown: ""; message: "" }
  | { status: "ready"; markdown: string; message: "" }
  | { status: "not-found" | "error"; markdown: ""; message: string };

const apiBaseURL = (import.meta.env.VITE_API_BASE_URL ?? "").replace(/\/$/, "");

function narrativeURL(cid: string): string {
  return `${apiBaseURL}/zero-trust-analytics/narratives/${encodeURIComponent(cid)}`;
}

function reportMatches(report: DemoReport, query: string): boolean {
  const normalized = query.trim().toLowerCase();
  if (normalized === "") {
    return true;
  }
  return (
    report.cid.toLowerCase().includes(normalized) ||
    report.platforms.some((platform) => platform.toLowerCase().includes(normalized))
  );
}

export default function App() {
  const [selectedCID, setSelectedCID] = useState(demoReports[0].cid);
  const [query, setQuery] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [reloadVersion, setReloadVersion] = useState(0);
  const [narrative, setNarrative] = useState<NarrativeState>({
    status: "loading",
    markdown: "",
    message: "",
  });
  const deferredQuery = useDeferredValue(query);
  const selectedReport = demoReports.find((report) => report.cid === selectedCID) ?? demoReports[0];
  const matchingReports = demoReports.filter((report) => reportMatches(report, deferredQuery));
  const tableOfContents =
    narrative.status === "ready" ? reportTableOfContents(narrative.markdown) : [];

  useEffect(() => {
    const controller = new AbortController();
    setNarrative({ status: "loading", markdown: "", message: "" });
    setCopied(false);

    async function loadNarrative() {
      try {
        const response = await fetch(narrativeURL(selectedCID), {
          signal: controller.signal,
          headers: { Accept: "text/markdown, text/plain" },
        });
        if (response.status === 404) {
          setNarrative({
            status: "not-found",
            markdown: "",
            message: "No generated narrative exists for this CID.",
          });
          return;
        }
        if (!response.ok) {
          throw new Error(`The API returned HTTP ${response.status}.`);
        }

        const markdown = await response.text();
        if (markdown.trim() === "") {
          throw new Error("The API returned an empty narrative.");
        }
        setNarrative({ status: "ready", markdown, message: "" });
      } catch (error) {
        if (controller.signal.aborted) {
          return;
        }
        setNarrative({
          status: "error",
          markdown: "",
          message:
            error instanceof Error
              ? error.message
              : "The narrative could not be loaded from analyticsapi.",
        });
      }
    }

    void loadNarrative();
    return () => controller.abort();
  }, [selectedCID, reloadVersion]);

  function selectReport(cid: string) {
    setSelectedCID(cid);
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function copyCID() {
    await navigator.clipboard.writeText(selectedCID);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <button
          className="sidebar-toggle"
          type="button"
          aria-label="Open report list"
          aria-expanded={sidebarOpen}
          onClick={() => setSidebarOpen((open) => !open)}
        >
          <span />
          <span />
          <span />
        </button>

        <div className="brand-mark" aria-hidden="true">
          <span>Z</span>
        </div>
        <div className="brand-copy">
          <p>Security posture workspace</p>
          <h1>Zero Trust Assessment Reports</h1>
        </div>
        <div className="demo-label">
          <span /> Demo environment
        </div>
      </header>

      <div className="workspace">
        {sidebarOpen && (
          <button
            className="sidebar-scrim"
            aria-label="Close report list"
            type="button"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <aside className={`report-sidebar ${sidebarOpen ? "report-sidebar--open" : ""}`}>
          <div className="sidebar-heading">
            <div>
              <p className="eyebrow">Narrative library</p>
              <h2>Customer reports</h2>
            </div>
            <span className="report-count">{demoReports.length}</span>
          </div>

          <label className="search-field">
            <span className="search-icon" aria-hidden="true" />
            <span className="sr-only">Search reports</span>
            <input
              type="search"
              placeholder="Search CID or platform"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>

          <nav className="report-list" aria-label="Available CID reports">
            {matchingReports.map((report, index) => {
              const selected = report.cid === selectedCID;
              return (
                <button
                  key={report.cid}
                  className={`report-list-item ${selected ? "report-list-item--selected" : ""}`}
                  type="button"
                  aria-current={selected ? "page" : undefined}
                  onClick={() => selectReport(report.cid)}
                >
                  <span className="report-index">{String(index + 1).padStart(2, "0")}</span>
                  <span className="report-list-copy">
                    <strong>{compactCID(report.cid)}</strong>
                    <small>
                      {report.platforms.length} {report.platforms.length === 1 ? "platform" : "platforms"}
                      <span aria-hidden="true"> / </span>
                      {report.platforms.slice(0, 2).join(", ")}
                      {report.platforms.length > 2 ? ` +${report.platforms.length - 2}` : ""}
                    </small>
                  </span>
                </button>
              );
            })}
            {matchingReports.length === 0 && (
              <div className="empty-search">
                <strong>No matching reports</strong>
                <span>Try a CID fragment or platform name.</span>
              </div>
            )}
          </nav>
        </aside>

        <main className="report-workspace">
          <section className="report-toolbar" aria-label="Selected report details">
            <div>
              <p className="eyebrow">Selected customer identifier</p>
              <div className="cid-line">
                <code>{selectedCID}</code>
                <button className="copy-button" type="button" onClick={() => void copyCID()}>
                  {copied ? "Copied" : "Copy CID"}
                </button>
              </div>
            </div>
            <div className="toolbar-meta">
              <span className={`load-status load-status--${narrative.status}`}>
                <i />
                {narrative.status === "ready" && "Narrative ready"}
                {narrative.status === "loading" && "Loading narrative"}
                {narrative.status === "not-found" && "Not generated"}
                {narrative.status === "error" && "API unavailable"}
              </span>
              <span className="platform-count">
                {selectedReport.platforms.length} {selectedReport.platforms.length === 1 ? "platform" : "platforms"}
              </span>
            </div>
          </section>

          <div className="report-layout">
            <article className="report-paper">
              {narrative.status === "loading" && <LoadingReport />}
              {(narrative.status === "error" || narrative.status === "not-found") && (
                <ReportError
                  message={narrative.message}
                  status={narrative.status}
                  onRetry={() => setReloadVersion((version) => version + 1)}
                />
              )}
              {narrative.status === "ready" && (
                <div className="markdown-body">
                  <ReportMarkdown markdown={narrative.markdown} />
                </div>
              )}
            </article>

            {narrative.status === "ready" && tableOfContents.length > 0 && (
              <aside className="document-outline" aria-label="Report contents">
                <p className="eyebrow">On this report</p>
                <nav>
                  {tableOfContents.map((item) => (
                    <a
                      key={item.id}
                      className={item.depth === 3 ? "outline-child" : ""}
                      href={`#${item.id}`}
                    >
                      {item.label}
                    </a>
                  ))}
                </nav>
              </aside>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

function LoadingReport() {
  return (
    <div className="loading-report" aria-live="polite" aria-label="Loading narrative">
      <div className="loading-kicker" />
      <div className="loading-title" />
      <div className="loading-meta" />
      <div className="loading-rule" />
      {[92, 76, 88, 62, 84, 71].map((width, index) => (
        <div key={`${width}-${index}`} className="loading-line" style={{ width: `${width}%` }} />
      ))}
    </div>
  );
}

type ReportErrorProps = {
  message: string;
  status: "error" | "not-found";
  onRetry: () => void;
};

function ReportError({ message, status, onRetry }: ReportErrorProps) {
  return (
    <div className="report-error" role="alert">
      <div className="error-glyph" aria-hidden="true">
        {status === "not-found" ? "404" : "!"}
      </div>
      <p className="eyebrow">{status === "not-found" ? "Narrative unavailable" : "Connection problem"}</p>
      <h2>{status === "not-found" ? "This report has not been generated" : "Could not reach analyticsapi"}</h2>
      <p>{message}</p>
      <button type="button" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}
