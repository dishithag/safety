import GithubSlugger from "github-slugger";
import ReactMarkdown from "react-markdown";
import rehypeSlug from "rehype-slug";
import remarkGfm from "remark-gfm";

type ReportMarkdownProps = {
  markdown: string;
};

export type TableOfContentsItem = {
  depth: number;
  id: string;
  label: string;
};

function cleanHeading(value: string): string {
  return value
    .replace(/\[([^\]]+)]\([^)]*\)/g, "$1")
    .replace(/[`*_~]/g, "")
    .trim();
}

export function reportTableOfContents(markdown: string): TableOfContentsItem[] {
  const slugger = new GithubSlugger();

  return markdown.split("\n").flatMap((line) => {
    const match = /^(#{2,3})\s+(.+?)\s*$/.exec(line);
    if (!match) {
      return [];
    }

    const label = cleanHeading(match[2]);
    return [{ depth: match[1].length, id: slugger.slug(label), label }];
  });
}

export function ReportMarkdown({ markdown }: ReportMarkdownProps) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[rehypeSlug]}
      components={{
        a: ({ children, ...props }) => (
          <a {...props} rel="noreferrer" target="_blank">
            {children}
          </a>
        ),
        table: ({ children, ...props }) => (
          <div className="table-scroll" role="region" aria-label="Report table" tabIndex={0}>
            <table {...props}>{children}</table>
          </div>
        ),
      }}
    >
      {markdown}
    </ReactMarkdown>
  );
}

