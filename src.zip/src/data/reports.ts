export type DemoReport = {
  cid: string;
  platforms: string[];
};

export const demoReports: DemoReport[] = [
  {
    cid: "00000000000000000000000000000009c",
    platforms: ["Windows 10", "iOS"],
  },
  {
    cid: "0000000000000000000000000000007b2",
    platforms: ["Windows 11"],
  },
  {
    cid: "000000000000000000000000000003a1",
    platforms: ["macOS"],
  },
  {
    cid: "0f53593ceae34995af8fd295c18f1e25",
    platforms: ["Windows 11", "Windows 10", "macOS"],
  },
  {
    cid: "11ab00000000000000000000000000018",
    platforms: ["Windows 11"],
  },
  {
    cid: "22cd0000000000000000000000000004c",
    platforms: ["Windows 10", "Android"],
  },
  {
    cid: "3a3a3a3a000044448888cccc12345678",
    platforms: [
      "Windows Server 2025",
      "Windows Server 2022",
      "Windows Server 2019",
      "Linux",
    ],
  },
  {
    cid: "9e8d7c6b5a4039281706f5e4d3c2b1a0",
    platforms: ["iOS", "Android", "macOS", "Windows 11"],
  },
  {
    cid: "a17c4e9b22f04d6e8b3a1f7c90de5521",
    platforms: ["Windows 10", "Windows 11", "macOS"],
  },
  {
    cid: "abcabcabcabcabcabcabcabcabcabc12",
    platforms: [
      "Windows 11",
      "Windows 10",
      "Windows Server 2022",
      "macOS",
      "Linux",
    ],
  },
  {
    cid: "bd7700000000000000000000000002500",
    platforms: ["Linux"],
  },
  {
    cid: "c8b9d0e1f2a3456789abcdef01234567",
    platforms: ["Windows 11", "Windows 10", "macOS", "Linux", "Android", "iOS"],
  },
  {
    cid: "cc5500000000000000000000000003300",
    platforms: ["Windows 11"],
  },
  {
    cid: "deadbeefcafef00d0123456789abcdef",
    platforms: ["Windows 11", "Windows 10", "macOS", "Linux", "Android", "iOS"],
  },
  {
    cid: "ffffffff111122223333444455556666",
    platforms: [
      "Windows 11",
      "Windows 10",
      "Windows Server 2025",
      "Windows Server 2022",
      "Windows Server 2019",
      "Windows Server 2016",
      "macOS",
      "Linux",
      "Android",
      "iOS",
    ],
  },
];

export function compactCID(cid: string): string {
  return `${cid.slice(0, 7)}...${cid.slice(-6)}`;
}

